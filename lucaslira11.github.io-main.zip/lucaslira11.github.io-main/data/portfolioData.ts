// src/data/portfolioData.ts

export const personalInfo = {
  name: "Lucas",
  fullName: "Lucas Lira",
  role: "Desenvolvedor Full-Stack",
  about: "Desenvolvedor na Turinq e estudante de Sistemas de Informação no CEFET/RJ. Especialista em criar soluções de alto desempenho, unindo lógica rigorosa a interfaces intuitivas e modernas.",
  email: "lucasponteslira@email.com",
};

export const skills = [
  { name: "Frontend", description: "Interfaces modernas e responsivas", items: ["React", "Next.js", "TypeScript", "Tailwind CSS"], icon: "Monitor" },
  { name: "Backend", description: "Sistemas escaláveis e seguros", items: ["Spring Boot", "PHP", "Node.js", "MySQL"], icon: "Database" },
  { name: "Mobile & Design", description: "Criação de apps e protótipos", items: ["Kotlin", "Figma", "After Effects", "Jetpack Compose"], icon: "Smartphone" }
];

export const projects = [
  {
    id: "busai",
    title: "Artigo sobre Agente BDI (busAI)",
    description: "Uma exploração profunda sobre arquiteturas de agentes inteligentes e tomada de decisão racional.",
    tech: ["IA", "Agentes BDI", "SBC"],
    image: "/banner-busai.png",
    featured: true,
    category: "Artigo Científico",
    details: {
      subtitle: "Arquiteturas de agentes inteligentes para mobilidade urbana.",
      tags: ["Inteligência Artificial", "Agentes BDI", "WESAAC 2025"],
      gallery: ["/professorpantoja.jpg"], // Apenas uma foto
      sections: [
        {
          title: "Visão Geral",
          isHighlight: false,
          content: [
            "Este artigo explora como agentes autônomos podem tomar decisões e agir de forma racional em ambientes dinâmicos, utilizando a arquitetura BDI.",
            "O projeto 'busAI' serve como um estudo de caso prático aplicado ao gerenciamento de transporte público."
          ]
        },
        {
          title: "Reconhecimento Acadêmico",
          isHighlight: true,
          content: [
            "Publicado na revista da Sociedade Brasileira de Computação (SBC).",
            "Selecionado para apresentação no WESAAC 2025."
          ]
        }
      ],
      disclaimer: "Este projeto é de natureza acadêmica e demonstra a aplicação de conceitos de Inteligência Artificial.",
      actionLink: "https://sol.sbc.org.br/index.php/wesaac/article/view/37550",
      actionText: "Ler Artigo Online"
    }
  },
  {
    id: "transito-seguro",
    title: "Projeto Trânsito Seguro Friburgo",
    description: "Iniciativa de conscientização viária desenvolvida para a cidade de Nova Friburgo.",
    tech: ["HTML5", "CSS3", "JavaScript"],
    image: "/projetotransitoseguro.png",
    featured: true,
    category: "Projeto Web / Social",
    details: {
      subtitle: "Um esforço coletivo para um trânsito mais seguro.",
      tags: ["HTML5", "CSS3", "JavaScript", "Conscientização"],
      sections: [
        {
          title: "O Problema e Missão",
          isHighlight: false,
          content: [
            "O site foi concebido devido aos alarmantes dados de acidentes em Nova Friburgo.",
            "Nosso objetivo é promover a conscientização e contribuir ativamente para a redução de acidentes."
          ]
        }
      ],
      disclaimer: "Projeto acadêmico desenvolvido no CEFET/RJ - Campus Nova Friburgo.",
      actionLink: "https://lucaslira11.github.io/transitoseguro/",
      actionText: "Acessar o Site"
    }
  },
  {
    id: "hidrate-bem",
    title: "Aplicativo HIDRATE BEM",
    description: "Sistema completo de monitoramento de hidratação diária com Android Nativo.",
    tech: ["Android Studio", "Kotlin", "Jetpack Compose"],
    image: "/banner-hidratebem.png",
    featured: true,
    category: "Mobile App",
    details: {
      subtitle: "Demonstração de competências em desenvolvimento Android nativo.",
      tags: ["Kotlin", "Jetpack Compose", "DataStore"],
      gallery: ["/foto-hidrate.png"], // Apenas uma foto
      sections: [
        {
          title: "Desenvolvimento",
          isHighlight: false,
          content: [
            "Aplicativo desenvolvido em Kotlin com Jetpack Compose, focado em uma interface intuitiva.",
            "Uso de AlarmManager e BroadcastReceiver para notificações e resets diários de consumo."
          ]
        }
      ],
      disclaimer: "Projeto focado em demonstrar competências técnicas em Android Nativo.",
      actionLink: "/hidratabem-v1.1.apk",
      actionText: "Baixar APK"
    }
  },
  {
    id: "sindiserfrj",
    title: "Site SINDISERF/RJ",
    description: "Site institucional com atualizações de notícias de forma contínua.",
    tech: ["PHP", "WordPress"],
    image: "/site1.png",
    featured: false,
    category: "Web",
    siteLink: "https://sindiserfrj.org.br",
    details: null
  },
  {
    id: "racing",
    title: "Site modelo RACING",
    description: "Site profissional com informações gerais sobre oficina de carros.",
    tech: ["TypeScript", "React"],
    image: "/capa-racing.png",
    featured: false,
    category: "Web",
    siteLink: "https://modelo-racing.vercel.app/",
    details: null
  },
  {
    id: "copa2026",
    title: "Simulador Copa 2026",
    description: "Site feito para simular confrontos da Copa com funcionalidade de simulação automática via IA.",
    tech: ["TypeScript", "IA"],
    image: "/capa-copa.png",
    featured: false,
    category: "Web",
    siteLink: "https://simulador-copa-2026.vercel.app/",
    details: null
  }
];