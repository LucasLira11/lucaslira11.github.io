// src/app/page.tsx
'use client';

import { motion } from 'framer-motion';
import { Monitor, Database, Smartphone, ExternalLink } from 'lucide-react';
import { FiGithub, FiLinkedin } from 'react-icons/fi';
import Link from 'next/link';
import Image from 'next/image';
import Logo from '@/components/Logo';
import { personalInfo, skills, projects } from '@/data/portfolioData';

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const iconMap = { Monitor, Database, Smartphone };

export default function Home() {
  const featuredProjects = projects.filter(p => p.featured);

  return (
    <div className="bg-neutral-950 text-white min-h-screen selection:bg-red-600 selection:text-white">
      {/* Navbar */}
      <nav className="fixed w-full z-50 backdrop-blur-md bg-neutral-950/80 border-b border-neutral-900">
        <div className="max-w-6xl mx-auto px-6 h-20 flex items-center justify-between">
          <Logo />
          <div className="hidden md:flex gap-8 text-sm font-medium text-neutral-400">
            <a href="#sobre" className="hover:text-red-500 transition-colors">Sobre</a>
            <a href="#skills" className="hover:text-red-500 transition-colors">Skills</a>
            <a href="#projetos" className="hover:text-red-500 transition-colors">Projetos</a>
            <a href="#contato" className="hover:text-red-500 transition-colors">Contato</a>
          </div>
        </div>
      </nav>

      <main>
        {/* HERO */}
        <section className="pt-40 pb-20 px-6 max-w-6xl mx-auto min-h-[90vh] flex flex-col justify-center">
          <motion.div initial="hidden" animate="visible" variants={fadeUp}>
            <p className="text-red-600 font-mono mb-4 text-lg font-semibold tracking-widest">WEB DEVELOPER @ TURINQ</p>
            <h1 className="text-6xl md:text-8xl font-bold tracking-tighter mb-6 leading-tight">
              Criando <br /> <span className="text-neutral-500 italic">facilidades.</span>
            </h1>
            <p className="text-neutral-400 text-xl max-w-2xl mb-10 leading-relaxed">
              {personalInfo.about}
            </p>
            <div className="flex flex-wrap gap-6 items-center">
              <a href="#projetos" className="bg-red-600 hover:bg-red-700 px-10 py-4 rounded-full font-bold transition-all hover:scale-105 shadow-xl shadow-red-600/20">
                Ver Portfólio
              </a>
              <div className="flex gap-6 text-neutral-400">
                <a href="https://github.com/lucaslira11" target="_blank" className="hover:text-red-600 transition-colors"><FiGithub size={28}/></a>
                <a href="https://www.linkedin.com/in/lucas-lira-79b339272/" className="hover:text-red-600 transition-colors"><FiLinkedin size={28}/></a>
              </div>
            </div>
          </motion.div>
        </section>

        {/* SOBRE */}
        <section id="sobre" className="py-32 px-6 max-w-6xl mx-auto border-t border-neutral-900">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
              <h2 className="text-3xl font-bold mb-8 flex items-center gap-4">
                <span className="text-red-600 font-mono text-xl">01.</span> Sobre Mim
              </h2>
              <div className="space-y-6 text-neutral-400 text-lg leading-relaxed">
                <p>Sou o <span className="text-white font-medium">Lucas Lira</span>, desenvolvedor apaixonado por transformar problemas complexos em interfaces fluidas e intuitivas.</p>
                <p>Com experiência na <span className="text-red-500">Turinq</span>, aprendi que o segredo de um projeto perfeito está no equilíbrio entre uma arquitetura backend sólida e um frontend que respira design.</p>
                <p>Atualmente foco-me em aprofundar o meu conhecimento no sistema <span className="text-white italic">ArcGIS e em GeoTecnologia</span> em geral, explorando também o mundo dos sistemas inteligentes e mobile.</p>
              </div>
            </motion.div>
            
            {/* Imagem com Hover a Preto e Branco, Redimensionada e com Zoom */}
            <div className="relative group flex justify-center">
              <div className="absolute inset-0 border-2 border-red-600 rounded-3xl translate-x-25 translate-y-4 transition-transform duration-500 w-full h-full max-w-[280px]"></div>
              <div className="relative aspect-square bg-neutral-900 rounded-3xl overflow-hidden border border-neutral-800 w-full max-w-[280px]">
                <Image 
                  src="/fotoperfil.png" 
                  alt="Lucas" 
                  fill 
                  className="object-cover object-top grayscale-0 group-hover:grayscale transition-all duration-700" 
                />
              </div>
            </div>
          </div>
        </section>

        {/* SKILLS */}
        <section id="skills" className="py-32 px-6 max-w-6xl mx-auto border-t border-neutral-900">
          <h2 className="text-3xl font-bold mb-20">
            <span className="text-red-600 font-mono text-xl">02.</span> Habilidades Técnicas
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {skills.map((skill, idx) => {
              const Icon = iconMap[skill.icon as keyof typeof iconMap];
              return (
                <motion.div key={idx} whileHover={{ y: -10 }} className="p-10 rounded-[2.5rem] bg-neutral-900 border border-neutral-800 hover:border-red-600/30 transition-all group relative overflow-hidden">
                  <div className="absolute -right-8 -top-8 w-32 h-32 bg-red-600/5 rounded-full blur-3xl group-hover:bg-red-600/10 transition-colors"></div>
                  <div className="w-16 h-16 bg-red-600/10 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-red-600 transition-colors duration-300">
                    <Icon className="text-red-600 group-hover:text-white" size={32} />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">{skill.name}</h3>
                  <p className="text-neutral-500 text-sm mb-8 leading-relaxed">{skill.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {skill.items.map(item => (
                      <span key={item} className="text-[10px] font-mono uppercase tracking-widest px-3 py-1.5 bg-neutral-950 rounded-lg border border-neutral-800 text-red-500">
                        {item}
                      </span>
                    ))}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </section>

        {/* PROJETOS DESTAQUE */}
        <section id="projetos" className="py-32 px-6 max-w-6xl mx-auto border-t border-neutral-900">
          <div className="flex justify-between items-end mb-20">
            <h2 className="text-3xl font-bold">
              <span className="text-red-600 font-mono text-xl">03.</span> Projetos em Foco
            </h2>
            <Link href="/projetos" className="group flex items-center gap-2 text-red-600 font-bold hover:gap-4 transition-all">
              TODOS OS PROJETOS <ExternalLink size={18}/>
            </Link>
          </div>

          <div className="space-y-32">
            {featuredProjects.map((project, idx) => (
              <motion.div 
                key={project.id}
                initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-100px" }} variants={fadeUp}
                className={`flex flex-col ${idx % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'} gap-12 items-center group`}
              >
                <div className="w-full md:w-1/2 relative aspect-video rounded-3xl overflow-hidden border border-neutral-800 shadow-2xl">
                  <Image src={project.image} alt={project.title} fill className="object-cover group-hover:scale-110 transition-transform duration-1000" />
                  <div className="absolute inset-0 bg-red-950/20 group-hover:bg-transparent transition-all" />
                </div>
                <div className={`w-full md:w-1/2 ${idx % 2 === 0 ? 'md:text-left' : 'md:text-right md:items-end'} flex flex-col`}>
                  <span className="text-red-600 font-mono text-sm mb-2 font-bold tracking-widest">{project.category}</span>
                  <h3 className="text-4xl font-bold mb-6">{project.title}</h3>
                  <div className="bg-neutral-900/50 backdrop-blur-sm p-8 rounded-3xl border border-neutral-800 shadow-xl mb-8">
                    <p className="text-neutral-400 text-lg leading-relaxed">{project.description}</p>
                  </div>
                  <div className="flex flex-wrap gap-4 mt-2">
                    <Link href={`/projetos/${project.id}`} className="flex items-center gap-2 px-6 py-3 bg-neutral-900 hover:bg-red-600 text-white text-sm rounded-full transition-all font-bold tracking-wider hover:scale-105">
                      VER DETALHES <ExternalLink size={16}/>
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* CONTATO */}
        <section id="contato" className="py-40 px-6 max-w-4xl mx-auto text-center">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <h2 className="text-5xl font-bold mb-8 tracking-tighter">Vamos construir algo <span className="text-red-600 underline">juntos?</span></h2>
            <p className="text-neutral-400 text-xl mb-12">Estou disponível para novos projetos e colaborações.</p>
            <a href="https://wa.me/5522997793222" className="inline-block bg-white text-black px-12 py-5 rounded-full font-black hover:bg-red-600 hover:text-white transition-all transform hover:-translate-y-2">
              ENTRAR EM CONTATO
            </a>
          </motion.div>
        </section>
      </main>

      <footer className="py-10 border-t border-neutral-900 text-center text-neutral-600 font-mono text-xs uppercase tracking-[0.3em]">
        © 2026 Lucas Lira • Developed with Next.js
      </footer>
    </div>
  );
}